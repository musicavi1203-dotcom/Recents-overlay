# recents-overlay

שירות נגישות שמחליף את מסך Recents של ה-Launcher במסך רשימה משלו (עד 15 אפליקציות אחרונות).

## התקנה והפעלה (דרך Shizuku)

```
pm install -r recents-overlay-debug.apk
pm grant com.abraham.recentsoverlay android.permission.PACKAGE_USAGE_STATS
settings put secure enabled_accessibility_services com.abraham.recentsoverlay/.RecentsWatchService
settings put secure accessibility_enabled 1
```

## בנייה

הפרויקט נבנה אוטומטית ב-GitHub Actions. ה-APK מופיע בתוצאות ה-workflow תחת `recents-overlay-debug`.
