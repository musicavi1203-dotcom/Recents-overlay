package com.abraham.recentsoverlay

import android.accessibilityservice.AccessibilityService
import android.app.usage.UsageStatsManager
import android.content.Intent
import android.graphics.Color
import android.graphics.PixelFormat
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView

/**
 * Full-screen list of recently used apps, shown on top of the system screen.
 * Lists up to MAX_ITEMS apps from UsageStatsManager (needs PACKAGE_USAGE_STATS).
 */
class RecentsOverlay(private val service: AccessibilityService) {

    private val wm = service.getSystemService(AccessibilityService.WINDOW_SERVICE) as WindowManager
    private var root: View? = null

    fun show() {
        if (root != null) return

        val pm = service.packageManager
        val content = LinearLayout(service).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(48, 120, 48, 48)
        }

        val packages = recentPackages()
        if (packages.isEmpty()) {
            content.addView(TextView(service).apply {
                text = "אין נתוני שימוש. צריך לתת הרשאת PACKAGE_USAGE_STATS"
                setTextColor(Color.WHITE)
                textSize = 16f
            })
        }

        for (pkg in packages) {
            val info = try {
                pm.getApplicationInfo(pkg, 0)
            } catch (e: Exception) {
                continue
            }

            val row = LinearLayout(service).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                setPadding(0, 24, 0, 24)
                setOnClickListener { launch(pkg) }
            }
            row.addView(ImageView(service).apply {
                setImageDrawable(pm.getApplicationIcon(info))
                layoutParams = LinearLayout.LayoutParams(96, 96).apply { rightMargin = 32 }
            })
            row.addView(TextView(service).apply {
                text = pm.getApplicationLabel(info)
                setTextColor(Color.WHITE)
                textSize = 18f
            })
            content.addView(row)
        }

        val full = LinearLayout(service).apply {
            setBackgroundColor(0xE6000000.toInt())
            addView(ScrollView(service).apply { addView(content) })
            // Tapping the dimmed background closes the list.
            setOnClickListener { hide() }
        }

        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.TOP }

        wm.addView(full, params)
        root = full
    }

    fun hide() {
        root?.let {
            try {
                wm.removeView(it)
            } catch (e: Exception) {
                // View already removed; nothing to do.
            }
        }
        root = null
    }

    private fun launch(pkg: String) {
        val intent = service.packageManager.getLaunchIntentForPackage(pkg) ?: return
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        hide()
        service.startActivity(intent)
    }

    private fun recentPackages(): List<String> {
        val usm = service.getSystemService(UsageStatsManager::class.java) ?: return emptyList()
        val end = System.currentTimeMillis()
        val start = end - 7L * 24 * 60 * 60 * 1000
        val stats = usm.queryUsageStats(UsageStatsManager.INTERVAL_DAILY, start, end) ?: return emptyList()

        return stats
            .filter { it.lastTimeUsed > 0 }
            .sortedByDescending { it.lastTimeUsed }
            .map { it.packageName }
            .filter { it != service.packageName && it != RecentsWatchService.LAUNCHER_PACKAGE }
            .distinct()
            .take(MAX_ITEMS)
    }

    companion object {
        const val MAX_ITEMS = 15
    }
}
