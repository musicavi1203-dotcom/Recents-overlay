package com.abraham.recentsoverlay

import android.accessibilityservice.AccessibilityService
import android.util.Log
import android.view.accessibility.AccessibilityEvent

class RecentsWatchService : AccessibilityService() {

    private val overlay by lazy { RecentsOverlay(this) }
    private var lastTriggerMs = 0L

    override fun onAccessibilityEvent(event: AccessibilityEvent) {
        if (event.packageName?.toString() != LAUNCHER_PACKAGE) return
        val cls = event.className?.toString() ?: return
        if (!cls.contains("RecentsActivity")) return

        val now = System.currentTimeMillis()
        if (now - lastTriggerMs < 500) return
        lastTriggerMs = now

        Log.d(TAG, "Recents opened: $cls")
        performGlobalAction(GLOBAL_ACTION_BACK)
        overlay.show()
    }

    override fun onInterrupt() {
        overlay.hide()
    }

    override fun onDestroy() {
        overlay.hide()
        super.onDestroy()
    }

    companion object {
        const val TAG = "RecentsWatch"
        const val LAUNCHER_PACKAGE = "com.android.launcher3"
    }
}
